
public class invalidMonthForWeddingHallException extends Exception{
	
public  invalidMonthForWeddingHallException(String message) {//constructor
	super(message);
}
}

