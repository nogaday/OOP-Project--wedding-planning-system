import java.util.Vector;

public class Couple  {
	private Person p1;
	private Person p2;
	private Vector<Person> guestList;
	private double maxPriceForDish;
	private boolean indoor;
	private boolean outdoor;

	public Couple(Person A, Person B,double maxPriceForDish,boolean indoor ,boolean outdoor) throws noHallTypeSelectedException {//constructor
		this.p1=new Person(A);
		this.p2=new Person(B);
		this.maxPriceForDish=maxPriceForDish;
		this.indoor=indoor;
		this.outdoor=outdoor;
		this.guestList = new Vector<Person>();
		if (!outdoor && !indoor)// if no type of hall was selected
		{
			throw new noHallTypeSelectedException("select at least one kind of hall");

		}
	}

	public void addToGuestList(Person guest) throws outOfBoundGuestListExeption{// add guests to the guest list

		if (guestList.size()>=500) // can't contain more than 500 guests
			throw new outOfBoundGuestListExeption("cannot invite more than 500 guests");
		else
			guestList.add(guest);

	}
	public boolean outdoor() {//getter
		return outdoor;
	}
	public boolean indoor() {//getter
		return indoor;
	}
	public double  maxPriceForDish() {//getter
		return maxPriceForDish;
	}
	public Person  getA() {//getter 
		return p1;
	}
	public Person  getB() {//getter
		return p2;
	}
	public Vector <Person> GetGuestList(){//getter
		return guestList;
	}
	public double GetmaxPriceForDish() {//getter
		return maxPriceForDish;
	}

	public boolean wantBoth() {//getter
		return (indoor && outdoor );
	}
	private boolean wantOnlyGarden() {//getter
		return (indoor && !outdoor );
	}
	private boolean wantOnltRoofed() {// getter
		return (!indoor && outdoor );
	}

}
