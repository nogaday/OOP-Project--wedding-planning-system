
public interface locatable {
	
public Location GetLocation();//method
}
