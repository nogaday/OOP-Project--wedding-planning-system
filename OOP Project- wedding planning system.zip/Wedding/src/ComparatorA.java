import java.util.Comparator;

public class ComparatorA implements Comparator<EventHall>{

	public int compare(EventHall A, EventHall B) {//compare by food rating
		if (A.GetFoodRating() > B.GetFoodRating()) {
			return 1;
		}

		else if (A.GetFoodRating() < B.GetFoodRating()) {
			return -1;
		}
		return 0;
	}
}