
public class Outdoor extends EventHall {
	private int openningMonth;
	private int closingMonth;
	private double C;	

	public Outdoor(String name,Location location,int maxGuests,int minGuests,int foodRating,int openningMonth,int closingMonth)throws invalidMonthForWeddingHallException {// constructor
		super(name, location, maxGuests, minGuests, foodRating);
		this.closingMonth=closingMonth;
		this.openningMonth=openningMonth;
		this.Type="GardenEevents";
		this.C = (closingMonth-openningMonth+1)/9.0;
		this.priceForDish = calcFoodPrice();		

		if (closingMonth>=11)// invalid month
			throw new invalidMonthForWeddingHallException("cannot book a Garden event for months 11, 12");
	}

	public double getPriceForDish() {//getter
		return priceForDish;
	}

	public double calcFoodPrice() {// calculates price for dish
		return 700*A*B*C;
	}

	public boolean isOpen( int wantedMonth) {//return if the garden hall is open
		return (this.openningMonth<= wantedMonth && this.closingMonth>= wantedMonth );
	}

}
