
public class Person implements locatable {
	private int idNum;
	private String firstname;
	private String lastname;
	private Location homeAdress;

	public Person(int id, String firstName, String lastName, Location location) {//constructor
		idNum=id;
		firstname=firstName;
		lastname=lastName;
		homeAdress=new Location(location);
	}

	public Person(Person other) {// copy constructor
		this(other.idNum, other.firstname, other.lastname, other.homeAdress);
	}

	public Location GetLocation() {// adress getter
		return homeAdress;
	}
	public int GetId() {//getter
		return idNum;
	}
	public String GetName() {//getter
		return firstname;
	}
	public String GetLastName() {//getter
		return lastname;
	}

}
