import java.util.Comparator;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.FileReader;

public class eventHallMatcher  {
	private  Vector <Couple> coupleList;
	private  Vector <locatable> invitedList;
	private Vector <EventHall> EventHalls;

	public eventHallMatcher (String couples, String invited, String eventHall) {// constructor

		coupleList = new Vector<Couple>();
		invitedList = new Vector<locatable>();
		EventHalls = new Vector<EventHall>();
		readFile (couples);
		readFile (eventHall);
		readFile (invited);

	}


	private void readFile(String file) {// initiates hall, couple and invited lists
		try {
			FileReader readFile = new FileReader(file);
			BufferedReader TranslateFile = new BufferedReader(readFile);
			String Line = TranslateFile.readLine();
			Line = TranslateFile.readLine();
			while (Line != null) {//while we didn't finish reading the text
				String[] fields = Line.split("	");// Divide every line to fields
				if (file.contains("couples.txt")) {//if it is couple text
					AddCouple(fields);

				}
				if (file.contains("invited.txt")) {//if it is invited text
					AddGuest(fields);

				}
				if (file.contains("eventHall.txt")) {//if it is eventhall text
					AddEventHall(fields);
				}
				Line = TranslateFile.readLine();
			} 
			TranslateFile.close();
			readFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	private void AddCouple(String [] fields) {// add couple to couple list
		try {
			Location place = new Location(Double.parseDouble(fields[7]), Double.parseDouble(fields[8]));
			Person PersonA = new Person(Integer.parseInt(fields[0]), fields[1], fields[2], place);
			Person PersonB = new Person(Integer.parseInt(fields[3]), fields[4], fields[5], place);
			Couple toAdd = new Couple(PersonA, PersonB, Double.parseDouble(fields[6]),//make new couple according to text
					Boolean.parseBoolean(fields[9]), Boolean.parseBoolean(fields[10]));
			coupleList.add(toAdd);
		}
		catch (noHallTypeSelectedException e) {
			e.printStackTrace();
		}
	}

	private void AddGuest(String []fields) {// add guest to invited list
		Location place = new Location(Double.parseDouble(fields[3]), Double.parseDouble(fields[4]));
		Person person = new Person(Integer.parseInt(fields[0]), fields[1], fields[2], place);// make new person according to text
		invitedList.add(person);

		for (int i = 0; i < coupleList.size(); i++) {
			int hostId = Integer.parseInt(fields[5]);// person who invited the guest
			int personA = coupleList.get(i).getA().GetId();
			int personB = coupleList.get(i).getB().GetId();
			if (hostId == personA||  hostId == personB) {
				try {
					coupleList.get(i).addToGuestList(person);// add guest to the relevant invited list
				} catch (outOfBoundGuestListExeption e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void AddEventHall(String []fields) {// add the event halls from text
		try {
			Location place = new Location(Double.parseDouble(fields[1]), Double.parseDouble(fields[2]));
			if (!fields[6].equals("")) { // has open month
				Outdoor outdoor = new Outdoor (fields[0], place, Integer.parseInt(fields[3]),// make new outdoor hall from text
						Integer.parseInt(fields[4]), Integer.parseInt(fields[5]), Integer.parseInt(fields[6]),
						Integer.parseInt(fields[7]));
				EventHalls.add(outdoor);
			} else {
				Indoor indoor = new Indoor(fields[0], place, Integer.parseInt(fields[3]),// make new indoor from text
						Integer.parseInt(fields[4]), Integer.parseInt(fields[5]), Integer.parseInt(fields[8]));
				EventHalls.add(indoor);
			}}
		catch (invalidMonthForWeddingHallException e) {
			e.printStackTrace();
		}
		catch (invalidOpeningYearExeption e) {}
	}


	public static <T extends locatable> double avgDistanceOfListFromLocation(Vector <T> tocompare, locatable c) {// calculates average distance of lacatable objects to elements from list
		int VectorLength=tocompare.size();
		double ans = 0;
		for (int i = 0; i<VectorLength; i ++) {
			ans+= c.GetLocation().distance(tocompare.elementAt(i).GetLocation());
		}
		return ans/VectorLength;
	}

	public Vector <EventHall> potentialEventHalls(Couple c){// returns a list of potential halls to every couple
		Vector <EventHall> PotentialHalls = new Vector <EventHall>();
		for (int i = 0; i < EventHalls.size(); i ++) {
			if ((EventHalls.elementAt(i).GetmaxGuests()>=c.GetGuestList().size())) {
				if(EventHalls.elementAt(i).GetpriceForDish () <= c.GetmaxPriceForDish()){
					if (EventHalls.elementAt(i).GetType().equals("GardenEevents")){
						if (c.outdoor()) {
							PotentialHalls.add(EventHalls.elementAt(i));
						}
					}	

					else {
						if (c.indoor())
							PotentialHalls.add(EventHalls.elementAt(i));	
					}
				}

			}


		}
		return PotentialHalls;
	}


	public void cheapestEventHall () {//returns the cheapest event hall for each couple
		for (int i = 0; i < coupleList.size(); i ++ ) {
			Vector <EventHall > GetHalls = potentialEventHalls(coupleList.elementAt(i));
			if (GetHalls.isEmpty())//no hall mach for the couple
				System.out.println("No match for couple "+coupleList.elementAt(i).getA().GetName() + " and "+ coupleList.elementAt(i).getB().GetName()+ ".");
			else {
				EventHall cheapest = minInList(GetHalls);
				System.out.println("Cheapest event hall for "+ coupleList.elementAt(i).getA().GetName() + " and " +coupleList.elementAt(i).getB().GetName() +" is "+ cheapest.GetName()+".");
			}
		}
	}

	public static <T> T MaxInList(Vector <T> list, Comparator <T> c ) {// find the max according to comparator
		if(list.isEmpty())//empty list
			return null;
		T max = list.elementAt(0);
		for (int i = 1; i < list.size(); i ++) {
			if (c.compare(max, list.elementAt(i))<0)
				max=list.elementAt(i);
		}
		return max;
	}

	public void bestFoodEventHall() {//returns the hall with the best food rating for each couple
		ComparatorA helper = new  ComparatorA();// comparing by food level
		for (int j=0; j<coupleList.size(); j++) {
			Vector <EventHall> potentialHalls=potentialEventHalls(coupleList.elementAt(j));//find potential halls for each couple
			if (potentialHalls == null) {
				System.out.println("There is no match");
			}
			else {
				EventHall max = MaxInList(potentialHalls, helper);// find hall with best food rating
				System.out.println("The recommended event hall for " + coupleList.elementAt(j).getA().GetName()+ " and " +coupleList.elementAt(j).getB().GetName() +" is " + max.GetName());
			}
		}

	}

	public  void printAvgDistanceOfCouples() {// prints relevant halls for every couple and the average distance of guests from it
		for (int i = 0; i<coupleList.size();i++) {
			System.out.println("for the couple "+ coupleList.elementAt(i).getA().GetName()+ " and " +coupleList.elementAt(i).getB().GetName() +
					" the potential halls and the average distance are: ");
			Vector <EventHall> PotentialHalls= potentialEventHalls( coupleList.elementAt(i));
			for (int j = 0; j < PotentialHalls.size(); j ++) {
				System.out.println("hall number " + j + " is " +PotentialHalls.elementAt(j).GetName());
				System.out.println("average distance from hall: " +
						avgDistanceOfListFromLocation(coupleList.elementAt(i).GetGuestList(), PotentialHalls.elementAt(j)));// calculate the average distance of guests from location
			}
		}
	}

	public static <T extends Comparable<T>> T minInList (Vector <T> ComparableList){//returns minimum object
		if(ComparableList.isEmpty())// if the list is empty
			return null;

		T min = ComparableList.get(0);
		for (int i = 1; i<ComparableList.size(); i ++) {
			if (ComparableList.elementAt(i).compareTo(min) < 0)
				min = ComparableList.elementAt(i);
		}
		return min;
	}


}
