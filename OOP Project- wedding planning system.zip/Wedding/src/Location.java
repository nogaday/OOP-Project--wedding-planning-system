
public class Location {
	private double latitude;
	private double longitude;

	public Location(double latitude, double longitude) {// constructor
		this.latitude=latitude;
		this.longitude=longitude;

	}

	public Location(Location other) {// copy constructor
		this(other.latitude, other.longitude);
	}

	public double distanceFromCenter() {// caltulates distance from 0,0
		return Math.sqrt(Math.pow(latitude, 2) +  Math.pow(longitude, 2));
	}


	public double distance(Location other) {// calculated distance between 2 points
		double latitudeDifference=this.latitude-other.getLatitude();
		double longitudeDifference	= this.longitude-other.getLongitude();
		return Math.sqrt(Math.pow(latitudeDifference, 2)+Math.pow(longitudeDifference, 2));

	}

	public double getLongitude() {//getter 
		return this.longitude;
	}

	public double getLatitude() {//getter
		return this.latitude;
	}

}
