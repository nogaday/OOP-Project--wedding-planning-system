
public class noHallTypeSelectedException extends Exception {
	
public noHallTypeSelectedException(String message) {//constructor
	super(message);
}
}
