
public class invalidOpeningYearExeption extends Exception {
	
public invalidOpeningYearExeption(String message) {//constructor
	super(message);
}
}
