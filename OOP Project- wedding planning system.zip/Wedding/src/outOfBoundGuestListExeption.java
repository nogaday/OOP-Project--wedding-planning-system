
public class outOfBoundGuestListExeption extends Exception {
	
	public outOfBoundGuestListExeption(String message) {//constructor
		super(message);
	}
}
