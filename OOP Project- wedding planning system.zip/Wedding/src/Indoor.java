
public class Indoor extends EventHall {
	private int openningYear;
	private double D;

	public Indoor(String name,Location location,int maxGuests,int minGuests,int foodRating, int openningYear ) throws  invalidOpeningYearExeption {//constructor
		super(name, location, maxGuests, minGuests, foodRating);
		if (openningYear<= 1989)
			throw new invalidOpeningYearExeption("cannot use halls that were built before 1989");
		else this.openningYear=openningYear;

		this.D=1-((2019-openningYear)/30.0);
		this.priceForDish=calcFoodPrice();
		this.Type="roofedHall";

	}

	public  double getPriceForDish() {//getter 
		return priceForDish;
	}

	public  double getOpenningYear() {//getter
		return this.openningYear;
	}


	public double calcFoodPrice() {// calculates price for dish
		return 700*A*B*D;
	}
}

