
abstract public class EventHall implements locatable, Comparable<EventHall>{
	protected String name;
	protected Location location;
	protected int maxGuests;
	protected int minGuests;
	protected int foodRating;
	protected double priceForDish;
	protected double A;
	protected double B;
	protected String Type="";

	public EventHall(String name,Location location, int maxGuests,int minGuests, int foodRating) {// constructor 
		this.name=name;
		this.location=new Location(location);
		this.maxGuests=maxGuests;
		this.minGuests=minGuests;
		this.foodRating=foodRating;
		this.A=foodRating / 10.0;
		this.B=1-(location.distanceFromCenter()/100);
	}
	protected int GetFoodRating() {//getter
		return foodRating;
	}

	protected String GetType() {//getter
		return this.Type ;
	}

	public Location GetLocation() {// getter
		return this.location;
	}
	public String GetName() {//getter
		return this.name;
	}

	public double GetpriceForDish () {//getter
		return this.priceForDish;
	}

	public int GetmaxGuests () {//getter
		return this.maxGuests;
	}
	public int GetminGuests () {//getter
		return this.minGuests;
	}

	public abstract double calcFoodPrice();//calculate price for dish

	public int compareTo(EventHall other) {// compare by price for dish
		if (this.priceForDish > other.priceForDish) {
			return 1;
		}
		else if (this.priceForDish < other.priceForDish) {
			return -1;
		}
		else
			return 0;
	}
}
